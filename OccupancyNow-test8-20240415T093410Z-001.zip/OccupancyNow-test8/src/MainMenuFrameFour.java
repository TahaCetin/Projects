import java.util.*;
import javax.swing.*;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenuFrameFour extends JFrame{

		public MainMenuFrameFour() {
			
			super("OccupancyNow");
			setSize(1215,810);
			setLayout(null);
			setBackground(Color.lightGray);
			setResizable(false);
			
			JPanel rightPanel = new JPanel();
			rightPanel.setBounds(1140,0,75,810);
			rightPanel.setBackground(Color.DARK_GRAY);
			add(rightPanel);
			
			JPanel leftPanel = new JPanel();
			leftPanel.setBounds(0,0,75,810);
			leftPanel.setBackground(Color.DARK_GRAY);
			add(leftPanel);
			
			JPanel bottomPanel = new JPanel();
			bottomPanel.setBounds(0,700,1215,1);
			bottomPanel.setBackground(Color.DARK_GRAY);
			add(bottomPanel);
			
			JPanel topPanel = new JPanel();
			topPanel.setBounds(0,80,1215,1);
			topPanel.setBackground(Color.DARK_GRAY);
			add(topPanel);
			
			JButton reservationsButton = new JButton("Reservations");
			reservationsButton.setBounds(130,710,170,60);
			ReservationsButtonHandler handler1 = new ReservationsButtonHandler();
			reservationsButton.addActionListener(handler1);
			add(reservationsButton);
			
			JButton mainMenuButton = new JButton("Main Menu");
			mainMenuButton.setBounds(525,710,170,60);
			MainMenuButtonHandler handler2 = new MainMenuButtonHandler();
			mainMenuButton.addActionListener(handler2);
			add(mainMenuButton);
			
			JButton offersButton = new JButton("Offers");
			offersButton.setBounds(915,710,170,60);	
			OffersButtonHandler handler3 = new OffersButtonHandler();
			offersButton.addActionListener(handler3);
			add(offersButton);
			
			JTextField searchBar = new JTextField();
			searchBar.setBounds(865,28,180,45);
			searchBar.setFont(new Font("Plain", Font.PLAIN, 18));
			add(searchBar);
			
			Image searchImg = new ImageIcon(this.getClass().getResource("search.png")).getImage();
			JButton searchButton = new JButton(new ImageIcon(searchImg));
			searchButton.setBounds(1050,30,50,40);
			searchButton.setContentAreaFilled(false);
			searchButton.setBorderPainted(false);
			add(searchButton);
			
			Image nameImg = new ImageIcon(this.getClass().getResource("OccupancyNow2.png")).getImage();
			JLabel nameLabel = new JLabel();
			nameLabel.setIcon(new ImageIcon(nameImg));
			nameLabel.setBounds(380,28,450,60);
			add(nameLabel);
			
			Image accountImg = new ImageIcon(this.getClass().getResource("account3.png")).getImage();
			JButton accountButton = new JButton();
			accountButton.setIcon(new ImageIcon(accountImg));
			accountButton.setBounds(170,25,50,50);
			accountButton.setContentAreaFilled(false);
			accountButton.setBorderPainted(false);
			AccountButtonHandler handler5 = new AccountButtonHandler();
			accountButton.addActionListener(handler5);
			add(accountButton);
			
			Image exitImg = new ImageIcon(this.getClass().getResource("exit.png")).getImage();
			JButton exitButton = new JButton();
			exitButton.setIcon(new ImageIcon(exitImg));
			exitButton.setBounds(100,25,50,50);
			exitButton.setContentAreaFilled(false);
			exitButton.setBorderPainted(false);
			ExitButtonHandler handler4 = new ExitButtonHandler();
			exitButton.addActionListener(handler4);
			add(exitButton);
			
			Image settingsImg = new ImageIcon(this.getClass().getResource("settings.png")).getImage();
			JButton settingsButton = new JButton();
			settingsButton.setIcon(new ImageIcon(settingsImg));
			settingsButton.setBounds(240,25,50,50);
			settingsButton.setContentAreaFilled(false);
			settingsButton.setBorderPainted(false);
			SettingsButtonHandler handler6 = new SettingsButtonHandler();
			settingsButton.addActionListener(handler6);
			add(settingsButton);
	

			
			JPanel restaurantPanel1 = new JPanel();
			restaurantPanel1.setBackground(Color.white);
			restaurantPanel1.setBounds(210,110,300,225);
			restaurantPanel1.setLayout(null);
			add(restaurantPanel1);
			restaurantPanel1.setLayout(null);
			restaurantPanel1.setVisible(true);
			
			JLabel restaurantNameLabel1 = new JLabel();
			restaurantNameLabel1.setBackground(Color.white);
			restaurantNameLabel1.setBounds(60,15,100,40);
			restaurantNameLabel1.setText("Pizza Hut");
			restaurantNameLabel1.setFont(new Font("Italic", Font.ITALIC, 18));
			restaurantPanel1.add(restaurantNameLabel1);
			
			JLabel restaurantRatingLabel1 = new JLabel();
			restaurantRatingLabel1.setBackground(Color.white);
			restaurantRatingLabel1.setBounds(50,170,70,40);
			restaurantRatingLabel1.setText("9.2/10");
			restaurantRatingLabel1.setFont(new Font("Italic", Font.ITALIC, 16));
			restaurantPanel1.add(restaurantRatingLabel1);
			
			Image ratingIcon = new ImageIcon(this.getClass().getResource("ratingnew.png")).getImage();
			JLabel restaurantRatingIcon1 = new JLabel();
			restaurantRatingIcon1.setIcon(new ImageIcon(ratingIcon));
			restaurantRatingIcon1.setBounds(17,162,80,50);
			restaurantPanel1.add(restaurantRatingIcon1);
			
			Image addressIcon = new ImageIcon(this.getClass().getResource("location2.png")).getImage();
			JLabel restaurantAddressIcon1 = new JLabel();
			restaurantAddressIcon1.setIcon(new ImageIcon(addressIcon));
			restaurantAddressIcon1.setBounds(245,165,80,50);
			restaurantPanel1.add(restaurantAddressIcon1);
			
			JLabel restaurantAddressLabel1 = new JLabel();
			restaurantAddressLabel1.setBackground(Color.white);
			restaurantAddressLabel1.setBounds(175,170,70,40);
			restaurantAddressLabel1.setText("Ataşehir");
			restaurantAddressLabel1.setFont(new Font("Italic", Font.ITALIC, 16));
			restaurantPanel1.add(restaurantAddressLabel1);
			
			Image petıcon = new ImageIcon(this.getClass().getResource("pet.png")).getImage();
			JLabel petIcon1 = new JLabel();
			petIcon1.setIcon(new ImageIcon(petıcon));
			petIcon1.setBounds(240,10,60,60);
			restaurantPanel1.add(petIcon1);
			
			Image parkıcon1 = new ImageIcon(this.getClass().getResource("park.png")).getImage();
			JLabel parkIcon1 = new JLabel();
			parkIcon1.setIcon(new ImageIcon(parkıcon1));
			parkIcon1.setBounds(240,60,60,60);
			restaurantPanel1.add(parkIcon1);
			
			JButton button1 = new JButton("Go");
			button1.setBounds(125,90,70,70);
			button1Handler handler7 = new button1Handler();
			button1.addActionListener(handler7);
			button1.setFont(new Font("Plain", Font.PLAIN, 16));
			button1.setForeground(Color.blue);
			restaurantPanel1.add(button1);
			
			
			Image restaurantIcon1 = new ImageIcon(this.getClass().getResource("pizzastore.png")).getImage();
			JLabel restaurantIconLabel1 = new JLabel();
			restaurantIconLabel1.setIcon(new ImageIcon(restaurantIcon1));
			restaurantIconLabel1.setBounds(10,7,60,60);
			restaurantPanel1.add(restaurantIconLabel1);
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			JPanel restaurantPanel2 = new JPanel();
			restaurantPanel2.setBackground(Color.white);
			restaurantPanel2.setBounds(700,110,300,225);
			restaurantPanel2.setLayout(null);
			add(restaurantPanel2);
			restaurantPanel2.setVisible(true);	
			
			JLabel restaurantNameLabel2 = new JLabel();
			restaurantNameLabel2.setBackground(Color.white);
			restaurantNameLabel2.setBounds(50,15,100,40);
			restaurantNameLabel2.setText("Tatlıcım");
			restaurantNameLabel2.setFont(new Font("Italic", Font.ITALIC, 18));
			restaurantPanel2.add(restaurantNameLabel2);
			
			JLabel restaurantRatingLabel2 = new JLabel();
			restaurantRatingLabel2.setBackground(Color.white);
			restaurantRatingLabel2.setBounds(50,170,70,40);
			restaurantRatingLabel2.setText("7.8/10");
			restaurantRatingLabel2.setFont(new Font("Italic", Font.ITALIC, 16));
			restaurantPanel2.add(restaurantRatingLabel2);
			
			Image ratingIcon2 = new ImageIcon(this.getClass().getResource("ratingnew.png")).getImage();
			JLabel restaurantRatingIcon2 = new JLabel();
			restaurantRatingIcon2.setIcon(new ImageIcon(ratingIcon2));
			restaurantRatingIcon2.setBounds(17,162,80,50);
			restaurantPanel2.add(restaurantRatingIcon2);
			
			Image addressIcon2 = new ImageIcon(this.getClass().getResource("location2.png")).getImage();
			JLabel restaurantAddressIcon2 = new JLabel();
			restaurantAddressIcon2.setIcon(new ImageIcon(addressIcon2));
			restaurantAddressIcon2.setBounds(245,165,80,50);
			restaurantPanel2.add(restaurantAddressIcon2);
			
			JLabel restaurantAddressLabel2 = new JLabel();
			restaurantAddressLabel2.setBackground(Color.white);
			restaurantAddressLabel2.setBounds(175,170,80,40);
			restaurantAddressLabel2.setText("Kadıköy");
			restaurantAddressLabel2.setFont(new Font("Italic", Font.ITALIC, 16));
			restaurantPanel2.add(restaurantAddressLabel2);
			
			Image petıcon2 = new ImageIcon(this.getClass().getResource("pet.png")).getImage();
			JLabel petIcon2 = new JLabel();
			petIcon2.setIcon(new ImageIcon(petıcon2));
			petIcon2.setBounds(240,7,60,60);
			restaurantPanel2.add(petIcon2);
			
			Image parkıcon2 = new ImageIcon(this.getClass().getResource("park.png")).getImage();
			JLabel parkIcon2 = new JLabel();
			parkIcon2.setIcon(new ImageIcon(parkıcon2));
			parkIcon2.setBounds(240,57,60,60);
			restaurantPanel2.add(parkIcon2);
			
			JButton button2 = new JButton("Go");
			button2.setBounds(125,90,70,70);
			button2Handler handler8 = new button2Handler();
			button2.addActionListener(handler8);
			button2.setFont(new Font("Plain", Font.PLAIN, 16));
			button2.setForeground(Color.blue);
			restaurantPanel2.add(button2);
			
			Image restaurantIcon2 = new ImageIcon(this.getClass().getResource("cupcake.png")).getImage();
			JLabel restaurantIconLabel2 = new JLabel();
			restaurantIconLabel2.setIcon(new ImageIcon(restaurantIcon2));
			restaurantIconLabel2.setBounds(10,7,60,60);
			restaurantPanel2.add(restaurantIconLabel2);
			
	
			
			
			
			
			
			
			
			
			
			JPanel restaurantPanel3 = new JPanel();
			restaurantPanel3.setBackground(Color.white);
			restaurantPanel3.setBounds(210,390,300,225);
			add(restaurantPanel3);
			restaurantPanel3.setLayout(null);
			restaurantPanel3.setVisible(true);
			
			
			JLabel restaurantNameLabel3 = new JLabel();
			restaurantNameLabel3.setBackground(Color.white);
			restaurantNameLabel3.setBounds(60,15,100,40);
			restaurantNameLabel3.setText("Pide Evi");
			restaurantNameLabel3.setFont(new Font("Italic", Font.ITALIC, 18));
			restaurantPanel3.add(restaurantNameLabel3);
			
			JLabel restaurantRatingLabel3 = new JLabel();
			restaurantRatingLabel3.setBackground(Color.white);
			restaurantRatingLabel3.setBounds(50,170,70,40);
			restaurantRatingLabel3.setText("5.9/10");
			restaurantRatingLabel3.setFont(new Font("Italic", Font.ITALIC, 16));
			restaurantPanel3.add(restaurantRatingLabel3);
			
			Image ratingIcon3 = new ImageIcon(this.getClass().getResource("ratingnew.png")).getImage();
			JLabel restaurantRatingIcon3 = new JLabel();
			restaurantRatingIcon3.setIcon(new ImageIcon(ratingIcon3));
			restaurantRatingIcon3.setBounds(17,162,80,50);
			restaurantPanel3.add(restaurantRatingIcon3);
			
			Image addressIcon3 = new ImageIcon(this.getClass().getResource("location2.png")).getImage();
			JLabel restaurantAddressIcon3 = new JLabel();
			restaurantAddressIcon3.setIcon(new ImageIcon(addressIcon3));
			restaurantAddressIcon3.setBounds(245,165,80,50);
			restaurantPanel3.add(restaurantAddressIcon3);
			
			JLabel restaurantAddressLabel3 = new JLabel();
			restaurantAddressLabel3.setBackground(Color.white);
			restaurantAddressLabel3.setBounds(180,170,70,40);
			restaurantAddressLabel3.setText("Pendik");
			restaurantAddressLabel3.setFont(new Font("Italic", Font.ITALIC, 16));
			restaurantPanel3.add(restaurantAddressLabel3);
			
			Image petıcon3 = new ImageIcon(this.getClass().getResource("pet.png")).getImage();
			JLabel petIcon3 = new JLabel();
			petIcon3.setIcon(new ImageIcon(petıcon3));
			petIcon3.setBounds(240,10,60,60);
			restaurantPanel3.add(petIcon3);
			
			Image parkıcon3 = new ImageIcon(this.getClass().getResource("park.png")).getImage();
			JLabel parkIcon3 = new JLabel();
			parkIcon3.setIcon(new ImageIcon(parkıcon3));
			parkIcon3.setBounds(240,60,60,60);
			restaurantPanel3.add(parkIcon3);
			
			JButton button3 = new JButton("Go");
			button3.setBounds(125,90,70,70);
			button3Handler handler9 = new button3Handler();
			button3.addActionListener(handler9);
			button3.setFont(new Font("Plain", Font.PLAIN, 16));
			button3.setForeground(Color.blue);
			restaurantPanel3.add(button3);
			
		
			
			Image restaurantIcon3 = new ImageIcon(this.getClass().getResource("pide.png")).getImage();
			JLabel restaurantIconLabel3 = new JLabel();
			restaurantIconLabel3.setIcon(new ImageIcon(restaurantIcon3));
			restaurantIconLabel3.setBounds(10,7,60,60);
			restaurantPanel3.add(restaurantIconLabel3);
			
			
			
			
			
			

			
			
			JPanel restaurantPanel4 = new JPanel();
			restaurantPanel4.setBackground(Color.white);
			restaurantPanel4.setBounds(700,390,300,225);
			add(restaurantPanel4);
			restaurantPanel4.setLayout(null);
			restaurantPanel4.setVisible(true);
			
			

			JLabel restaurantNameLabel4 = new JLabel();
			restaurantNameLabel4.setBackground(Color.white);
			restaurantNameLabel4.setBounds(60,15,100,40);
			restaurantNameLabel4.setText("Balıkevi");
			restaurantNameLabel4.setFont(new Font("Italic", Font.ITALIC, 18));
			restaurantPanel4.add(restaurantNameLabel4);
			
			JLabel restaurantRatingLabel4 = new JLabel();
			restaurantRatingLabel4.setBackground(Color.white);
			restaurantRatingLabel4.setBounds(50,170,70,40);
			restaurantRatingLabel4.setText("6.9/10");
			restaurantRatingLabel4.setFont(new Font("Italic", Font.ITALIC, 16));
			restaurantPanel4.add(restaurantRatingLabel4);
			
			Image ratingIcon4 = new ImageIcon(this.getClass().getResource("ratingnew.png")).getImage();
			JLabel restaurantRatingIcon4 = new JLabel();
			restaurantRatingIcon4.setIcon(new ImageIcon(ratingIcon4));
			restaurantRatingIcon4.setBounds(17,162,80,50);
			restaurantPanel4.add(restaurantRatingIcon4);
			
			Image addressIcon4 = new ImageIcon(this.getClass().getResource("location2.png")).getImage();
			JLabel restaurantAddressIcon4 = new JLabel();
			restaurantAddressIcon4.setIcon(new ImageIcon(addressIcon4));
			restaurantAddressIcon4.setBounds(245,165,70,50);
			restaurantPanel4.add(restaurantAddressIcon4);
			
			JLabel restaurantAddressLabel4 = new JLabel();
			restaurantAddressLabel4.setBackground(Color.white);
			restaurantAddressLabel4.setBounds(190,170,70,40);
			restaurantAddressLabel4.setText("Tuzla");
			restaurantAddressLabel4.setFont(new Font("Italic", Font.ITALIC, 16));
			restaurantPanel4.add(restaurantAddressLabel4);
			
		/*	Image petıcon4 = new ImageIcon(this.getClass().getResource("pet.png")).getImage();
			JLabel petIcon4 = new JLabel();
			petIcon4.setIcon(new ImageIcon(petıcon4));
			petIcon4.setBounds(240,7,60,60);
			restaurantPanel4.add(petIcon4);		*/
			
			Image parkıcon4 = new ImageIcon(this.getClass().getResource("park.png")).getImage();
			JLabel parkIcon4 = new JLabel();
			parkIcon4.setIcon(new ImageIcon(parkıcon4));
			parkIcon4.setBounds(240,57,60,60);
			restaurantPanel4.add(parkIcon4);
			
			JButton button4 = new JButton("Go");
			button4.setBounds(125,90,70,70);
			button4Handler handler10 = new button4Handler();
			button4.addActionListener(handler10);
			button4.setFont(new Font("Plain", Font.PLAIN, 16));
			button4.setForeground(Color.blue);
			restaurantPanel4.add(button4);
			
			Image restaurantIcon4 = new ImageIcon(this.getClass().getResource("balık.png")).getImage();
			JLabel restaurantIconLabel4 = new JLabel();
			restaurantIconLabel4.setIcon(new ImageIcon(restaurantIcon4));
			restaurantIconLabel4.setBounds(10,7,60,60);
			restaurantPanel4.add(restaurantIconLabel4);
			
			
			
			JLabel pageNumberLabel = new JLabel();
			pageNumberLabel.setText("Page 4");
			pageNumberLabel.setFont(new Font("Plain", Font.PLAIN, 16));
			pageNumberLabel.setBounds(580,625,100,60);
			add(pageNumberLabel);
			
			Image previousPageImg = new ImageIcon(this.getClass().getResource("arrowleft.png")).getImage();
			
			JButton previousPageButton = new JButton();
			previousPageButton.setIcon(new ImageIcon(previousPageImg));
			previousPageButton.setBounds(100,340,50,50);
			previousPageButton.setContentAreaFilled(false);
			previousPageButton.setBorderPainted(false);
			PreviousPageButtonHandler handlerrr = new PreviousPageButtonHandler();
			previousPageButton.addActionListener(handlerrr);
			add(previousPageButton);
			
			
			setVisible(true);
			
		}
		
		public void disposeThisFrame() {
			
			dispose();
			
		}
		
		private class ExitButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {
				JFrame frame = new JFrame();
				frame.setVisible(false);
				int a = JOptionPane.showConfirmDialog(frame,"Are you sure?");
				if(a == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
				else {
					frame.dispose();
				}
				
			}
				
		}
		
		private class AccountButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					AccountFrame frame = new AccountFrame();
				
				}
				
			}
		
		private class SettingsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					SettingsFrame frame = new SettingsFrame();
				
				}
				
			}
					
		private class ReservationsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();			
				Reservation frame = new Reservation();
								
			}
			
			
		}
		
		private class MainMenuButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				MainMenuFrameOne frame = new MainMenuFrameOne();
				
								
			}
			
			
		}
		
		private class OffersButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				OffersButtonFrame frame = new OffersButtonFrame();	
								
			}
			
			
		}
		
		private class PreviousPageButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				MainMenuFrameThree frame = new MainMenuFrameThree();
				
								
			}
			
			
		}
		
		private class button1Handler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				restaurantPanel1 frame = new restaurantPanel1();
				
								
			}
			
			
		}
	
		
	private class button2Handler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				restaurantPanel2 frame = new restaurantPanel2();
				
								
			}
			
			
		}
	
	private class button3Handler implements ActionListener{
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			disposeThisFrame();
			restaurantPanel3 frame = new restaurantPanel3();
			
							
		}
		
		
	}

private class button4Handler implements ActionListener{
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			disposeThisFrame();
			restaurantPanel4 frame = new restaurantPanel4();
			
							
		}
  }
		
}