import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SignUpFrame extends JFrame{
		
		public SignUpFrame() {
			
			super("OccupancyNow");
			setSize(1215,810);
			setLayout(null);
			setBackground(Color.lightGray);
			setResizable(false);
			
			JPanel rightPanel = new JPanel();
			rightPanel.setBounds(1140,0,75,810);
			rightPanel.setBackground(Color.DARK_GRAY);
			add(rightPanel);
			
			JPanel leftPanel = new JPanel();
			leftPanel.setBounds(0,0,75,810);
			leftPanel.setBackground(Color.DARK_GRAY);
			add(leftPanel);
			
			JLabel topLabel = new JLabel("Come Join Us :) Sign Up!");
			topLabel.setBounds(440,40,500,120);
			topLabel.setFont(new Font("Roman", Font.ITALIC ,30));
			topLabel.setForeground(Color.gray);
			add(topLabel);
			
			JLabel usernameLabel = new JLabel();
			usernameLabel.setBounds(355,175,140,60);
			usernameLabel.setText("Username:");
			usernameLabel.setFont(new Font("Plain", Font.PLAIN, 21));
			add(usernameLabel);
			
			JTextField usernameField = new JTextField();
			usernameField.setBounds(500,185,300,60);
			usernameField.setFont(new Font("Plain", Font.PLAIN, 21));
			add(usernameField);
			
			Image okImg = new ImageIcon(this.getClass().getResource("ok.png")).getImage();
			
			JButton button1 = new JButton();
			button1.setIcon(new ImageIcon(okImg));
			button1.setBounds(805,185,60,60);
			button1.setContentAreaFilled(false);
	        button1.setBorderPainted(false);
			add(button1);
			
			
			JLabel phoneNumberLabel = new JLabel();
			phoneNumberLabel.setBounds(310,270,180,60);
			phoneNumberLabel.setText("Phone Number:");
			phoneNumberLabel.setFont(new Font("Plain", Font.PLAIN, 21));
			add(phoneNumberLabel);
			
			JTextField phoneNumberField = new JTextField();
			phoneNumberField.setBounds(500,275,300,60);
			phoneNumberField.setFont(new Font("Plain", Font.PLAIN, 21));
			add(phoneNumberField);
			
			JButton button2 = new JButton();
			button2.setIcon(new ImageIcon(okImg));
			button2.setBounds(805,275,60,60);
			button2.setContentAreaFilled(false);
	        button2.setBorderPainted(false);
			add(button2);
			
			JLabel passwordLabel = new JLabel();
			passwordLabel.setBounds(365,360,160,60);
			passwordLabel.setText("Password:");
			passwordLabel.setFont(new Font("Plain", Font.PLAIN, 21));
			add(passwordLabel);
			
			JPasswordField passwordField = new JPasswordField();
			passwordField.setBounds(500,365,300,60);
			passwordField.setFont(new Font("Plain", Font.PLAIN, 21));
			add(passwordField);
			
			JButton button3 = new JButton();
			button3.setIcon(new ImageIcon(okImg));
			button3.setBounds(805,365,60,60);
			button3.setContentAreaFilled(false);
	        button3.setBorderPainted(false);
			add(button3);
			
			JLabel repeatPasswordLabel = new JLabel();
			repeatPasswordLabel.setBounds(297,450,200,60);
			repeatPasswordLabel.setText("Password(Again):");
			repeatPasswordLabel.setFont(new Font("Plain", Font.PLAIN, 21));
			add(repeatPasswordLabel);
			
			JPasswordField repeatPasswordField = new JPasswordField();
			repeatPasswordField.setBounds(500,450,300,60);
			repeatPasswordField.setFont(new Font("Plain", Font.PLAIN, 21));
			add(repeatPasswordField);
			
			JButton button4 = new JButton();
			button4.setIcon(new ImageIcon(okImg));
			button4.setBounds(805,450,60,60);
			button4.setContentAreaFilled(false);
	        button4.setBorderPainted(false);
			add(button4);
			
			JButton createAccountButton = new JButton("Create Account");
			createAccountButton.setBounds(660,560,140,55);
			CreateAccountButtonHandler handler1 = new CreateAccountButtonHandler();
			createAccountButton.addActionListener(handler1);
			add(createAccountButton);
			
			JButton returnButton = new JButton("Return");
			returnButton.setBounds(500,560,90,55);
			ReturnButtonHandler handler2 = new ReturnButtonHandler();
			returnButton.addActionListener(handler2);
			add(returnButton);
			
			
			setVisible(true);
			
		}
		
		public void disposeThisFrame() {
			
			dispose();
			
		}
		
		private class CreateAccountButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				
				JFrame f=new JFrame(); 
				JOptionPane.showMessageDialog(f,"New account is created. Welcome:)","Response",JOptionPane.INFORMATION_MESSAGE);  

				
								
			}

		}
		
		private class ReturnButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				LoginFrame frame = new LoginFrame();
				
								
			}
	
		}
	
}
