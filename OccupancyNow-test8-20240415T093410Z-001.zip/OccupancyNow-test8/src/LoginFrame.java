import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame{

	
		public LoginFrame() {
			
		super("OccupancyNow");
		setSize(1215,810);
		setLayout(null);
		setBackground(Color.lightGray);
		setResizable(false);
		
		JPanel rightPanel = new JPanel();
		rightPanel.setBounds(1140,0,75,810);
		rightPanel.setBackground(Color.DARK_GRAY);
		add(rightPanel);
		
		JPanel leftPanel = new JPanel();
		leftPanel.setBounds(0,0,75,810);
		leftPanel.setBackground(Color.DARK_GRAY);
		add(leftPanel);
		
		Image nameImg = new ImageIcon(this.getClass().getResource("OccupancyNow.png")).getImage();
		
		JLabel name = new JLabel();
		name.setIcon(new ImageIcon(nameImg));
		name.setBounds(260,60,800,120);
		add(name);

		JLabel usernameLabel = new JLabel();
		usernameLabel.setBounds(350,260,140,80);
		usernameLabel.setText("Username:");
		usernameLabel.setFont(new Font("Plain", Font.PLAIN, 21));
		add(usernameLabel);
		
		JTextField usernameField = new JTextField();
		usernameField.setBounds(515,270,300,60);
		usernameField.setFont(new Font("Plain", Font.PLAIN, 21));
		add(usernameField);
		
		Image okImg = new ImageIcon(this.getClass().getResource("ok.png")).getImage();
		JButton button1 = new JButton();
		button1.setIcon(new ImageIcon(okImg));
		button1.setBounds(820,270,60,60);
		button1.setContentAreaFilled(false);
        button1.setBorderPainted(false);
		add(button1);
		
		JLabel passwordLabel = new JLabel();
		passwordLabel.setBounds(355,360,140,80);
		passwordLabel.setText("Password:");
		passwordLabel.setFont(new Font("Plain", Font.PLAIN, 21));
		add(passwordLabel);
		
		JPasswordField passwordField = new JPasswordField();
		passwordField.setBounds(515,370,300,60);
		passwordField.setFont(new Font("Plain", Font.PLAIN, 21));
		add(passwordField);
		
		JButton button2 = new JButton(new ImageIcon(okImg));
		button2.setBounds(820,370,60,60);
		button2.setContentAreaFilled(false);
        button2.setBorderPainted(false);
		add(button2);
		
		
		JButton okButton = new JButton("Ready,Go:)");
		okButton.setBounds(730,470,85,50);
		okButton.setBackground(Color.lightGray);
		add(okButton); 
		OkButtonHandler handler3 = new OkButtonHandler();
		okButton.addActionListener(handler3);
		
		JButton signUpButton = new JButton("Sign up!");
		signUpButton.setBounds(730,550,85,50);
		add(signUpButton);
		SignUpButtonHandler handler1 = new SignUpButtonHandler();
		signUpButton.addActionListener(handler1);
		
		JButton forgotMyPasswordButton = new JButton("Forgot Password:(");
		forgotMyPasswordButton.setBounds(515,470,170,50);
		add(forgotMyPasswordButton);
		ForgotPasswordButtonHandler handler2 = new ForgotPasswordButtonHandler();
		forgotMyPasswordButton.addActionListener(handler2);
		
		
		JButton aboutUsButton = new JButton("What is OccupancyNow?");
		aboutUsButton.setBounds(515,550,170,50);
		add(aboutUsButton);
		AboutUsButtonHandler handler0 = new AboutUsButtonHandler();
		aboutUsButton.addActionListener(handler0);

		setVisible(true);
		
		}
		
		public void disposeLoginFrame() {
			
			dispose();
			
		}
		
		private class AboutUsButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeLoginFrame();
				WhatIsOccupancyNowFrame frame = new WhatIsOccupancyNowFrame();
				
		}
		}
		private class SignUpButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
							
				disposeLoginFrame();
				SignUpFrame frame = new SignUpFrame();
					
			}
		}
		
		private class ForgotPasswordButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
							
				disposeLoginFrame();
				ForgotPasswordFrame frame = new ForgotPasswordFrame();
					
			}
		}
		
		private class OkButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
							
				disposeLoginFrame();
				MainMenuFrameOne frame = new MainMenuFrameOne();
					
			}
		}
				

}

