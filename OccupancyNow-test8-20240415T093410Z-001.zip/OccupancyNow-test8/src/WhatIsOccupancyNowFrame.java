import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class WhatIsOccupancyNowFrame extends JFrame{
		
		
		public WhatIsOccupancyNowFrame() {
			
			
			super("OccupancyNow");
			setSize(1215,810);
			setLayout(null);
			setBackground(Color.lightGray);
			setResizable(false);
			
			JPanel rightPanel = new JPanel();
			rightPanel.setBounds(1140,0,75,810);
			rightPanel.setBackground(Color.DARK_GRAY);
			add(rightPanel);
			
			JPanel leftPanel = new JPanel();
			leftPanel.setBounds(0,0,75,810);
			leftPanel.setBackground(Color.DARK_GRAY);
			add(leftPanel);
			
			JLabel topLabel = new JLabel("What Is OccupancyNow?");
			topLabel.setBounds(400,60,500,120);
			topLabel.setFont(new Font("Roman", Font.ITALIC ,36));
			topLabel.setForeground(Color.gray);
			
			JLabel label1 = new JLabel("The aim of OccupancyNow is designing an application where people");
			JLabel label2 = new JLabel("can be informed about cafes and restaurants like occupancy rate, wifi, menu,");
			JLabel label3 = new JLabel("service, offers which have significant place in their social and business life.");
			JLabel label4 = new JLabel("With this application, it is aimed to enable people to use the time");
			JLabel label5 = new JLabel("they spare for socializing or working outside more efficiently, and ");
			JLabel label6 = new JLabel("to receive better quality service for their wishes and purposes.");
		
			label1.setBounds(270,230,800,50);
			label2.setBounds(270,280,800,50);
			label3.setBounds(270,330,800,50);
			label4.setBounds(270,380,800,50);
			label5.setBounds(270,430,800,50);
			label6.setBounds(270,480,800,50);
			
			label1.setFont(new Font("Plain", Font.PLAIN, 20));
			label2.setFont(new Font("Plain", Font.PLAIN, 20));
			label3.setFont(new Font("Plain", Font.PLAIN, 20));
			label4.setFont(new Font("Plain", Font.PLAIN, 20));
			label5.setFont(new Font("Plain", Font.PLAIN, 20));
			label6.setFont(new Font("Plain", Font.PLAIN, 20));
			
			JButton okButton = new JButton("Got It!");
			okButton.setBounds(570,580,100,55);
			OkButtonHandler handler = new OkButtonHandler();
			okButton.addActionListener(handler);
			
			
			add(okButton);
			add(topLabel);
			add(label1);
			add(label2);
			add(label3);
			add(label4);
			add(label5);
			add(label6);
			
			setVisible(true);
			
		}
		
		public void disposeThisFrame() {
			
			dispose();
			
		}
		
		private class OkButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				LoginFrame frame = new LoginFrame();
				
		}

}
		
}
