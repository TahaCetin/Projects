import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class OffersButtonFrame extends JFrame{
		
		public OffersButtonFrame() {
			
			super("OccupancyNow");
			setSize(1215,810);
			setLayout(null);
			setBackground(Color.lightGray);
			setResizable(false);
			
			JPanel rightPanel = new JPanel();
			rightPanel.setBounds(1140,0,75,810);
			rightPanel.setBackground(Color.DARK_GRAY);
			add(rightPanel);
			
			JPanel leftPanel = new JPanel();
			leftPanel.setBounds(0,0,75,810);
			leftPanel.setBackground(Color.DARK_GRAY);
			add(leftPanel);
			
			JPanel bottomPanel = new JPanel();
			bottomPanel.setBounds(0,700,1215,1);
			bottomPanel.setBackground(Color.DARK_GRAY);
			add(bottomPanel);
			
			JPanel topPanel = new JPanel();
			topPanel.setBounds(0,80,1215,1);
			topPanel.setBackground(Color.DARK_GRAY);
			add(topPanel);
			
			JButton reservationsButton = new JButton("Reservations");
			reservationsButton.setBounds(130,710,170,60);
			ReservationsButtonHandler handler1 = new ReservationsButtonHandler();
			reservationsButton.addActionListener(handler1);
			add(reservationsButton);
			
			JButton mainMenuButton = new JButton("Main Menu");
			mainMenuButton.setBounds(520,710,170,60);
			MainMenuButtonHandler handler2 = new MainMenuButtonHandler();
			mainMenuButton.addActionListener(handler2);
			add(mainMenuButton);
			
			JButton offersButton = new JButton("Offers");
			offersButton.setBounds(915,710,170,60);	
			OffersButtonHandler handler3 = new OffersButtonHandler();
			offersButton.addActionListener(handler3);
			add(offersButton);
			
			JTextField searchBar = new JTextField();
			searchBar.setBounds(865,28,180,45);
			searchBar.setFont(new Font("Plain", Font.PLAIN, 18));
			add(searchBar);
			
			Image searchImg = new ImageIcon(this.getClass().getResource("search.png")).getImage();
			JButton searchButton = new JButton(new ImageIcon(searchImg));
			searchButton.setBounds(1050,30,50,40);
			searchButton.setContentAreaFilled(false);
			searchButton.setBorderPainted(false);
			add(searchButton);
			
			Image nameImg = new ImageIcon(this.getClass().getResource("OccupancyNow2.png")).getImage();
			JLabel nameLabel = new JLabel();
			nameLabel.setIcon(new ImageIcon(nameImg));
			nameLabel.setBounds(380,28,450,60);
			add(nameLabel);
			
			Image accountImg = new ImageIcon(this.getClass().getResource("account3.png")).getImage();
			JButton accountButton = new JButton();
			accountButton.setIcon(new ImageIcon(accountImg));
			accountButton.setBounds(170,25,50,50);
			accountButton.setContentAreaFilled(false);
			accountButton.setBorderPainted(false);
			AccountButtonHandler handler5 = new AccountButtonHandler();
			accountButton.addActionListener(handler5);
			add(accountButton);
			
			Image exitImg = new ImageIcon(this.getClass().getResource("exit.png")).getImage();
			JButton exitButton = new JButton();
			exitButton.setIcon(new ImageIcon(exitImg));
			exitButton.setBounds(100,25,50,50);
			exitButton.setContentAreaFilled(false);
			exitButton.setBorderPainted(false);
			ExitButtonHandler handler4 = new ExitButtonHandler();
			exitButton.addActionListener(handler4);
			add(exitButton);
			
			Image settingsImg = new ImageIcon(this.getClass().getResource("settings.png")).getImage();
			JButton settingsButton = new JButton();
			settingsButton.setIcon(new ImageIcon(settingsImg));
			settingsButton.setBounds(240,25,50,50);
			settingsButton.setContentAreaFilled(false);
			settingsButton.setBorderPainted(false);
			SettingsButtonHandler handler6 = new SettingsButtonHandler();
			settingsButton.addActionListener(handler6);
			add(settingsButton);
			
	
			JLabel reservationnamelabe1 = new JLabel();
			reservationnamelabe1.setBounds(535,170,200,50);
			reservationnamelabe1.setText("Reservations");
			reservationnamelabe1.setFont(new Font("Plain", Font.BOLD, 24));
			add(reservationnamelabe1);
			
			
			JPanel testField = new JPanel();
			testField.setBounds(80,160,1050,70);
			testField.setBackground(Color.white);
			testField.setLayout(null);
			add(testField);
					
		

			JLabel reservation1 = new JLabel();
			reservation1.setBackground(Color.white);
			reservation1.setBounds(225,250,350,50);
			reservation1.setText("CZN Burak:");
			reservation1.setFont(new Font("Italic", Font.ITALIC, 18));
			add(reservation1);
			 
			
			JLabel reservationtime1 = new JLabel();
			reservationtime1.setBackground(Color.white);
			reservationtime1.setBounds(725,250,400,50);
			reservationtime1.setText("%10 indirim");
			reservationtime1.setFont(new Font("Italic", Font.ITALIC, 18));
			add(reservationtime1);
			
			
			JPanel testField1 = new JPanel();
			testField1.setBounds(80,240,1050,70);
			testField1.setBackground(Color.white);
			testField1.setLayout(null);
			add(testField1);
						
			
			JLabel reservation2 = new JLabel();
			reservation2.setBackground(Color.white);
			reservation2.setBounds(225,330,400,50);
			reservation2.setText("Bursa Kebap Evi:");
			reservation2.setFont(new Font("Italic", Font.ITALIC, 18));
			add(reservation2);
			 
			
			JLabel reservationtime2 = new JLabel();
			reservationtime2.setBackground(Color.white);
			reservationtime2.setBounds(725,330,350,50);
			reservationtime2.setText("%15 indirim");
			reservationtime2.setFont(new Font("Italic", Font.ITALIC, 18));
			add(reservationtime2);
			
			
			JPanel testField2 = new JPanel();
			testField2.setBounds(80,320,1050,70);
			testField2.setBackground(Color.white);
			testField2.setLayout(null);
			add(testField2);
						
			
			JLabel reservation3 = new JLabel();
			reservation3.setBackground(Color.white);
			reservation3.setBounds(225,410,400,50);
			reservation3.setText("Happy Moons:");
			reservation3.setFont(new Font("Italic", Font.ITALIC, 18));
			add(reservation3);
			 
			
			JLabel reservationtime3 = new JLabel();
			reservationtime3.setBackground(Color.white);
			reservationtime3.setBounds(725,410,350,50);
			reservationtime3.setText("%20 indirim");
			reservationtime3.setFont(new Font("Italic", Font.ITALIC, 18));
			add(reservationtime3);
			
			JPanel testField3 = new JPanel();
			testField3.setBounds(80,400,1050,70);
			testField3.setBackground(Color.white);
			testField3.setLayout(null);
			add(testField3);
			
			JLabel reservation4 = new JLabel();
			reservation4.setBackground(Color.white);
			reservation4.setBounds(225,490,400,50);
			reservation4.setText("Neli Pide ");
			reservation4.setFont(new Font("Italic", Font.ITALIC, 18));
			add(reservation4);

			JLabel reservationtime4 = new JLabel();
			reservationtime4.setBackground(Color.white);
			reservationtime4.setBounds(725,490,350,50);
			reservationtime4.setText("%12 indirim");
			reservationtime4.setFont(new Font("Italic", Font.ITALIC, 18));
			add(reservationtime4);

			JPanel testField4 = new JPanel();
			testField4.setBounds(80,480,1050,70);
			testField4.setBackground(Color.white);
			testField4.setLayout(null);
			add(testField4);


			JLabel reservation5 = new JLabel();
			reservation5.setBackground(Color.white);
			reservation5.setBounds(225,570,400,50);
			reservation5.setText("Köfteci Ramiz:");
			reservation5.setFont(new Font("Italic", Font.ITALIC, 18));
			add(reservation5);

			JLabel reservationtime5 = new JLabel();
			reservationtime5.setBackground(Color.white);
			reservationtime5.setBounds(725,570,350,50);
			reservationtime5.setText("%8 indirim");
			reservationtime5.setFont(new Font("Italic", Font.ITALIC, 18));
			add(reservationtime5);

			JPanel testField5 = new JPanel();
			testField5.setBounds(80,560,1050,70);
			testField5.setBackground(Color.white);
			testField5.setLayout(null);
			add(testField5);

			
			setVisible(true);
			
		}
		
		public void disposeThisFrame() {
			
			dispose();
			
		}
		
		private class ExitButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {
				JFrame frame = new JFrame();
				frame.setVisible(false);
				int a = JOptionPane.showConfirmDialog(frame,"Are you sure?");
				if(a == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
				else {
					frame.dispose();
				}
				
			}
				
		}
		
		private class SettingsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					SettingsFrame frame = new SettingsFrame();
				
				}
				
			}
		
		private class AccountButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					AccountFrame frame = new AccountFrame();
					
				}
				
			}
				
		
		private class ReservationsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();	
				Reservation frame = new Reservation();
								
			}
			
			
		}
		
		private class MainMenuButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				MainMenuFrameOne frame = new MainMenuFrameOne();
				
								
			}
			
			
		}
		
		private class OffersButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();	
				OffersButtonFrame frame = new OffersButtonFrame();					
			}
				
		}
		
		
}
