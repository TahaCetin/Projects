import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Contact4 extends JFrame{
		
			public Contact4() {
			
			super("OccupancyNow");
			setSize(1215,810);
			setLayout(null);
			setBackground(Color.lightGray);
			setResizable(false);
			
			JPanel rightPanel = new JPanel();
			rightPanel.setBounds(1140,0,75,810);
			rightPanel.setBackground(Color.DARK_GRAY);
			add(rightPanel);
			
			JPanel leftPanel = new JPanel();
			leftPanel.setBounds(0,0,75,810);
			leftPanel.setBackground(Color.DARK_GRAY);
			add(leftPanel);
			
			JPanel bottomPanel = new JPanel();
			bottomPanel.setBounds(0,700,1215,1);
			bottomPanel.setBackground(Color.DARK_GRAY);
			add(bottomPanel);
			
			JPanel topPanel = new JPanel();
			topPanel.setBounds(0,80,1215,1);
			topPanel.setBackground(Color.DARK_GRAY);
			add(topPanel);
			
			JButton menuButton1 = new JButton("Menu");
			menuButton1.setBounds(120,80,170,60);
			menuButton1Handler handler11 = new menuButton1Handler();
			menuButton1.addActionListener(handler11);
			add(menuButton1);
			
			JButton menuButton2 = new JButton("Comments");
			menuButton2.setBounds(320,80,170,60);
			menuButton2Handler handler12 = new menuButton2Handler();
			menuButton2.addActionListener(handler12);
			add(menuButton2);
			
			JButton menuButton3 = new JButton("Seatting");
			menuButton3.setBounds(520,80,170,60);
			menuButton3Handler handler13 = new menuButton3Handler();
			menuButton3.addActionListener(handler13);
			add(menuButton3);
			
			JButton menuButton4 = new JButton("Events");
			menuButton4.setBounds(720,80,170,60);
			menuButton4Handler handler14 = new menuButton4Handler();
			menuButton4.addActionListener(handler14);
			add(menuButton4);
			
			JButton menuButton5 = new JButton("Contact");
			menuButton5.setBounds(920,80,170,60);
			menuButton5Handler handler15 = new menuButton5Handler();
			menuButton5.addActionListener(handler15);
			add(menuButton5);

			


			
			JButton reservationsButton = new JButton("Reservations");
			reservationsButton.setBounds(130,710,170,60);
			ReservationsButtonHandler handler1 = new ReservationsButtonHandler();
			reservationsButton.addActionListener(handler1);
			add(reservationsButton);
			
			JButton mainMenuButton = new JButton("Main Menu");
			mainMenuButton.setBounds(520,710,170,60);
			MainMenuButtonHandler handler2 = new MainMenuButtonHandler();
			mainMenuButton.addActionListener(handler2);
			add(mainMenuButton);
			
			JButton offersButton = new JButton("Offers");
			offersButton.setBounds(915,710,170,60);	
			OffersButtonHandler handler3 = new OffersButtonHandler();
			offersButton.addActionListener(handler3);
			add(offersButton);
			
			JTextField searchBar = new JTextField();
			searchBar.setBounds(865,28,180,45);
			searchBar.setFont(new Font("Plain", Font.PLAIN, 18));
			add(searchBar);
			
			Image searchImg = new ImageIcon(this.getClass().getResource("search.png")).getImage();
			JButton searchButton = new JButton(new ImageIcon(searchImg));
			searchButton.setBounds(1050,30,50,40);
			searchButton.setContentAreaFilled(false);
			searchButton.setBorderPainted(false);
			add(searchButton);
			
			Image nameImg = new ImageIcon(this.getClass().getResource("OccupancyNow2.png")).getImage();
			JLabel nameLabel = new JLabel();
			nameLabel.setIcon(new ImageIcon(nameImg));
			nameLabel.setBounds(380,28,450,60);
			add(nameLabel);
			
			Image accountImg = new ImageIcon(this.getClass().getResource("account3.png")).getImage();
			JButton accountButton = new JButton();
			accountButton.setIcon(new ImageIcon(accountImg));
			accountButton.setBounds(170,25,50,50);
			accountButton.setContentAreaFilled(false);
			accountButton.setBorderPainted(false);
			AccountButtonHandler handler5 = new AccountButtonHandler();
			accountButton.addActionListener(handler5);
			add(accountButton);
			
			Image exitImg = new ImageIcon(this.getClass().getResource("exit.png")).getImage();
			JButton exitButton = new JButton();
			exitButton.setIcon(new ImageIcon(exitImg));
			exitButton.setBounds(100,25,50,50);
			exitButton.setContentAreaFilled(false);
			exitButton.setBorderPainted(false);
			ExitButtonHandler handler4 = new ExitButtonHandler();
			exitButton.addActionListener(handler4);
			add(exitButton);
			
			Image settingsImg = new ImageIcon(this.getClass().getResource("settings.png")).getImage();
			JButton settingsButton = new JButton();
			settingsButton.setIcon(new ImageIcon(settingsImg));
			settingsButton.setBounds(240,25,50,50);
			settingsButton.setContentAreaFilled(false);
			settingsButton.setBorderPainted(false);
			SettingsButtonHandler handler6 = new SettingsButtonHandler();
			settingsButton.addActionListener(handler6);
			add(settingsButton);

			JLabel contactnamelabe1 = new JLabel();
			contactnamelabe1.setBounds(535,170,200,50);
			contactnamelabe1.setText("Contact");
			contactnamelabe1.setFont(new Font("Plain", Font.BOLD, 24));
			add(contactnamelabe1);
			
			
			JLabel contactPhonenum = new JLabel();
			contactPhonenum.setBackground(Color.white);
			contactPhonenum.setBounds(125,250,270,50);
			contactPhonenum.setText("Phone number:");
			contactPhonenum.setFont(new Font("Italic", Font.ITALIC, 18));
			add(contactPhonenum);
			
			JLabel contactAddr = new JLabel();
			contactAddr.setBackground(Color.white);
			contactAddr.setBounds(125,300,500,50);
			contactAddr.setText("Open adress:");
			contactAddr.setFont(new Font("Italic", Font.ITALIC, 18));
			add(contactAddr);

			JLabel contactMail1 = new JLabel();
			contactMail1.setBackground(Color.white);
			contactMail1.setBounds(125,350,270,50);
			contactMail1.setText("Mail:");
			contactMail1.setFont(new Font("Italic", Font.ITALIC, 18));
			add(contactMail1);
			
			
			JLabel contactPhoneNumber = new JLabel();
			contactPhoneNumber.setBackground(Color.white);
			contactPhoneNumber.setBounds(500,250,270,50);
			contactPhoneNumber.setText("0216 662 22 97");
			contactPhoneNumber.setFont(new Font("Italic", Font.ITALIC, 18));
			add(contactPhoneNumber);
			
			JLabel contactAddress = new JLabel();
			contactAddress.setBackground(Color.white);
			contactAddress.setBounds(500,300,500,50);
			contactAddress.setText("İstanbul, Bostancı,Atatürk Sokak No: 2");
			contactAddress.setFont(new Font("Italic", Font.ITALIC, 18));
			add(contactAddress);

			JLabel contactMail2 = new JLabel();
			contactMail2.setBackground(Color.white);
			contactMail2.setBounds(500,350,270,50);
			contactMail2.setText("info@coldstone.com.tr");
			contactMail2.setFont(new Font("Italic", Font.ITALIC, 18));
			add(contactMail2);
			
			JPanel testField = new JPanel();
			testField.setBounds(80,160,1050,70);
			testField.setBackground(Color.white);
			testField.setLayout(null);
			add(testField);
			
			JPanel testField1 = new JPanel();
			testField1.setBounds(80,240,1050,200);
			testField1.setBackground(Color.white);
			testField1.setLayout(null);
			add(testField1);
			
			
			
			setVisible(true);
		}
		
		public void disposeThisFrame() {
			
			dispose();
			
		}
		
		private class ExitButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {
				JFrame frame = new JFrame();
				frame.setVisible(false);
				int a = JOptionPane.showConfirmDialog(frame,"Are you sure?");
				if(a == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
				else {
					frame.dispose();
				}
				
			}
				
		}
		private class SettingsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					SettingsFrame frame = new SettingsFrame();
				
				}
				
			}
		private class AccountButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					AccountFrame frame = new AccountFrame();
					
				}
				
			}
		private class ReservationsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();	
				Reservation frame = new Reservation();
								
			}
			
			
		}		
		private class MainMenuButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				MainMenuFrameOne frame = new MainMenuFrameOne();
				
								
			}
			
			
		}
		private class OffersButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();	
				OffersButtonFrame frame = new OffersButtonFrame();					
			}
				
		}
		private class menuButton1Handler implements ActionListener{
	
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				restaurantPanel4 frame = new restaurantPanel4();					
			}
		
		}
		private class menuButton2Handler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				Comments4 frame = new Comments4();					
			}
		
		}
		private class menuButton3Handler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				sitting4 frame = new sitting4();					
			}
		
		}
		private class menuButton4Handler implements ActionListener{
	
	@Override
	public void actionPerformed(ActionEvent e) {

		disposeThisFrame();	
		Events4 frame = new Events4();					
	}

}
		private class menuButton5Handler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				Contact4 frame = new Contact4();					
			}
		
		}


}