import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class SettingsFrame extends JFrame{
		
		public SettingsFrame() {
			
			super("OccupancyNow");
			setSize(1215,810);
			setLayout(null);
			setBackground(Color.lightGray);
			setResizable(false);
			
			JPanel rightPanel = new JPanel();
			rightPanel.setBounds(1140,0,75,810);
			rightPanel.setBackground(Color.DARK_GRAY);
			add(rightPanel);
			
			JPanel leftPanel = new JPanel();
			leftPanel.setBounds(0,0,75,810);
			leftPanel.setBackground(Color.DARK_GRAY);
			add(leftPanel);
			
			JPanel bottomPanel = new JPanel();
			bottomPanel.setBounds(0,700,1215,1);
			bottomPanel.setBackground(Color.DARK_GRAY);
			add(bottomPanel);
			
			JPanel topPanel = new JPanel();
			topPanel.setBounds(0,80,1215,1);
			topPanel.setBackground(Color.DARK_GRAY);
			add(topPanel);
			
			JButton reservationsButton = new JButton("Reservations");
			reservationsButton.setBounds(130,710,170,60);
			ReservationsButtonHandler handler1 = new ReservationsButtonHandler();
			reservationsButton.addActionListener(handler1);
			add(reservationsButton);
			
			JButton mainMenuButton = new JButton("Main Menu");
			mainMenuButton.setBounds(520,710,170,60);
			MainMenuButtonHandler handler2 = new MainMenuButtonHandler();
			mainMenuButton.addActionListener(handler2);
			add(mainMenuButton);
			
			JButton offersButton = new JButton("Offers");
			offersButton.setBounds(915,710,170,60);	
			OffersButtonHandler handler3 = new OffersButtonHandler();
			offersButton.addActionListener(handler3);
			add(offersButton);
			
			JTextField searchBar = new JTextField();
			searchBar.setBounds(865,28,180,45);
			searchBar.setFont(new Font("Plain", Font.PLAIN, 18));
			add(searchBar);
			
			Image searchImg = new ImageIcon(this.getClass().getResource("search.png")).getImage();
			JButton searchButton = new JButton(new ImageIcon(searchImg));
			searchButton.setBounds(1050,30,50,40);
			searchButton.setContentAreaFilled(false);
			searchButton.setBorderPainted(false);
			add(searchButton);
			
			Image nameImg = new ImageIcon(this.getClass().getResource("OccupancyNow2.png")).getImage();
			JLabel nameLabel = new JLabel();
			nameLabel.setIcon(new ImageIcon(nameImg));
			nameLabel.setBounds(380,28,450,60);
			add(nameLabel);
			
			Image accountImg = new ImageIcon(this.getClass().getResource("account3.png")).getImage();
			JButton accountButton = new JButton();
			accountButton.setIcon(new ImageIcon(accountImg));
			accountButton.setBounds(170,25,50,50);
			accountButton.setContentAreaFilled(false);
			accountButton.setBorderPainted(false);
			AccountButtonHandler handler5 = new AccountButtonHandler();
			accountButton.addActionListener(handler5);
			add(accountButton);
			
			Image exitImg = new ImageIcon(this.getClass().getResource("exit.png")).getImage();
			JButton exitButton = new JButton();
			exitButton.setIcon(new ImageIcon(exitImg));
			exitButton.setBounds(100,25,50,50);
			exitButton.setContentAreaFilled(false);
			exitButton.setBorderPainted(false);
			ExitButtonHandler handler4 = new ExitButtonHandler();
			exitButton.addActionListener(handler4);
			add(exitButton);
			
			Image settingsImg = new ImageIcon(this.getClass().getResource("settings.png")).getImage();
			JButton settingsButton = new JButton();
			settingsButton.setIcon(new ImageIcon(settingsImg));
			settingsButton.setBounds(240,25,50,50);
			settingsButton.setContentAreaFilled(false);
			settingsButton.setBorderPainted(false);
			SettingsButtonHandler handler6 = new SettingsButtonHandler();
			settingsButton.addActionListener(handler6);
			add(settingsButton);
			
			JLabel settingsLabel = new JLabel();
			settingsLabel.setIcon(new ImageIcon(settingsImg));
			settingsLabel.setBounds(520,182,50,50);
			add(settingsLabel);
			
			JLabel infoLabel = new JLabel();
			infoLabel.setBounds(578,168,150,80);
			infoLabel.setFont(new Font("Italic", Font.ITALIC, 28));
			infoLabel.setText("Settings");
			add(infoLabel);
			
			JLabel usernameLabel = new JLabel();
			usernameLabel.setBounds(305,275,200,60);
			usernameLabel.setText("Change Username:");
			usernameLabel.setFont(new Font("Plain", Font.PLAIN, 21));
			add(usernameLabel);
			
			JTextField usernameField = new JTextField();
			usernameField.setBounds(520,285,300,60);
			usernameField.setFont(new Font("Plain", Font.PLAIN, 21));
			add(usernameField);
			
			JLabel passwordLabel = new JLabel();
			passwordLabel.setBounds(310,370,200,60);
			passwordLabel.setText("Change Password:");
			passwordLabel.setFont(new Font("Plain", Font.PLAIN, 21));
			add(passwordLabel);
			
			JPasswordField passwordField = new JPasswordField();
			passwordField.setBounds(520,375,300,60);
			passwordField.setFont(new Font("Plain", Font.PLAIN, 21));
			add(passwordField);
			
			JLabel phoneNumberLabel = new JLabel();
			phoneNumberLabel.setBounds(257,460,260,60);
			phoneNumberLabel.setText("Change Phone Number:");
			phoneNumberLabel.setFont(new Font("Plain", Font.PLAIN, 21));
			add(phoneNumberLabel);
			
			JTextField phoneNumberField = new JTextField();
			phoneNumberField.setBounds(520,465,300,60);
			phoneNumberField.setFont(new Font("Plain", Font.PLAIN, 21));
			add(phoneNumberField);
			
			Image okImg = new ImageIcon(this.getClass().getResource("ok.png")).getImage();
			
			JButton button1 = new JButton();
			button1.setIcon(new ImageIcon(okImg));
			button1.setBounds(835,295,40,40);
			button1.setContentAreaFilled(false);
	        button1.setBorderPainted(false);
			add(button1);
			
			JButton button2 = new JButton();
			button2.setIcon(new ImageIcon(okImg));
			button2.setBounds(835,385,40,40);
			button2.setContentAreaFilled(false);
	        button2.setBorderPainted(false);
			add(button2);
			
			JButton button3 = new JButton();
			button3.setIcon(new ImageIcon(okImg));
			button3.setBounds(835,475,40,40);
			button3.setContentAreaFilled(false);
	        button3.setBorderPainted(false);
			add(button3);
			
			
						
			setVisible(true);
		}
		
		public void disposeThisFrame() {
			
			dispose();
			
		}
		
		private class ExitButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {
				JFrame frame = new JFrame();
				frame.setVisible(false);
				int a = JOptionPane.showConfirmDialog(frame,"Are you sure?");
				if(a == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
				else {
					frame.dispose();
				}
				
			}
				
		}
		
		private class SettingsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					SettingsFrame frame = new SettingsFrame();
				
				}
				
			}
		
		private class AccountButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					AccountFrame frame = new AccountFrame();
					
				}
				
			}
				
		
		private class ReservationsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();			
				Reservation frame = new Reservation();
								
			}
			
			
		}
		
		private class MainMenuButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				MainMenuFrameOne frame = new MainMenuFrameOne();
				
								
			}
			
			
		}
		
		private class OffersButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();	
				OffersButtonFrame frame = new OffersButtonFrame();					
			}
				
		}
		
		
}
