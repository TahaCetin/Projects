import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class sitting3 extends JFrame{
		
		public sitting3() {
			
			super("OccupancyNow");
			setSize(1215,810);
			setLayout(null);
			setBackground(Color.lightGray);
			setResizable(false);
			
			JPanel rightPanel = new JPanel();
			rightPanel.setBounds(1140,0,75,810);
			rightPanel.setBackground(Color.DARK_GRAY);
			add(rightPanel);
			
			JPanel leftPanel = new JPanel();
			leftPanel.setBounds(0,0,75,810);
			leftPanel.setBackground(Color.DARK_GRAY);
			add(leftPanel);
			
			JPanel bottomPanel = new JPanel();
			bottomPanel.setBounds(0,700,1215,1);
			bottomPanel.setBackground(Color.DARK_GRAY);
			add(bottomPanel);
			
			JPanel topPanel = new JPanel();
			topPanel.setBounds(0,80,1215,1);
			topPanel.setBackground(Color.DARK_GRAY);
			add(topPanel);
			
			JButton menuButton1 = new JButton("Menu");
			menuButton1.setBounds(120,80,170,60);
			menuButton1Handler handler11 = new menuButton1Handler();
			menuButton1.addActionListener(handler11);
			add(menuButton1);
			
			JButton menuButton2 = new JButton("Comments");
			menuButton2.setBounds(320,80,170,60);
			menuButton2Handler handler12 = new menuButton2Handler();
			menuButton2.addActionListener(handler12);
			add(menuButton2);
			
			JButton menuButton3 = new JButton("Seatting");
			menuButton3.setBounds(520,80,170,60);
			menuButton3Handler handler13 = new menuButton3Handler();
			menuButton3.addActionListener(handler13);
			add(menuButton3);
			
			JButton menuButton4 = new JButton("Events");
			menuButton4.setBounds(720,80,170,60);
			menuButton4Handler handler14 = new menuButton4Handler();
			menuButton4.addActionListener(handler14);
			add(menuButton4);
			
			JButton menuButton5 = new JButton("Contact");
			menuButton5.setBounds(920,80,170,60);
			menuButton5Handler handler15 = new menuButton5Handler();
			menuButton5.addActionListener(handler15);
			add(menuButton5);
			
			JButton reservationsButton = new JButton("Reservations");
			reservationsButton.setBounds(130,710,170,60);
			ReservationsButtonHandler handler1 = new ReservationsButtonHandler();
			reservationsButton.addActionListener(handler1);
			add(reservationsButton);
			
			JButton mainMenuButton = new JButton("Main Menu");
			mainMenuButton.setBounds(520,710,170,60);
			MainMenuButtonHandler handler2 = new MainMenuButtonHandler();
			mainMenuButton.addActionListener(handler2);
			add(mainMenuButton);
			
			JButton offersButton = new JButton("Offers");
			offersButton.setBounds(915,710,170,60);	
			OffersButtonHandler handler3 = new OffersButtonHandler();
			offersButton.addActionListener(handler3);
			add(offersButton);
			
			JTextField searchBar = new JTextField();
			searchBar.setBounds(865,28,180,45);
			searchBar.setFont(new Font("Plain", Font.PLAIN, 18));
			add(searchBar);
			
			Image searchImg = new ImageIcon(this.getClass().getResource("search.png")).getImage();
			JButton searchButton = new JButton(new ImageIcon(searchImg));
			searchButton.setBounds(1050,30,50,40);
			searchButton.setContentAreaFilled(false);
			searchButton.setBorderPainted(false);
			add(searchButton);
			
			Image nameImg = new ImageIcon(this.getClass().getResource("OccupancyNow2.png")).getImage();
			JLabel nameLabel = new JLabel();
			nameLabel.setIcon(new ImageIcon(nameImg));
			nameLabel.setBounds(380,28,450,60);
			add(nameLabel);
			
			Image accountImg = new ImageIcon(this.getClass().getResource("account3.png")).getImage();
			JButton accountButton = new JButton();
			accountButton.setIcon(new ImageIcon(accountImg));
			accountButton.setBounds(170,25,50,50);
			accountButton.setContentAreaFilled(false);
			accountButton.setBorderPainted(false);
			AccountButtonHandler handler5 = new AccountButtonHandler();
			accountButton.addActionListener(handler5);
			add(accountButton);
			
			Image exitImg = new ImageIcon(this.getClass().getResource("exit.png")).getImage();
			JButton exitButton = new JButton();
			exitButton.setIcon(new ImageIcon(exitImg));
			exitButton.setBounds(100,25,50,50);
			exitButton.setContentAreaFilled(false);
			exitButton.setBorderPainted(false);
			ExitButtonHandler handler4 = new ExitButtonHandler();
			exitButton.addActionListener(handler4);
			add(exitButton);
			
			Image settingsImg = new ImageIcon(this.getClass().getResource("settings.png")).getImage();
			JButton settingsButton = new JButton();
			settingsButton.setIcon(new ImageIcon(settingsImg));
			settingsButton.setBounds(240,25,50,50);
			settingsButton.setContentAreaFilled(false);
			settingsButton.setBorderPainted(false);
			SettingsButtonHandler handler6 = new SettingsButtonHandler();
			settingsButton.addActionListener(handler6);
			add(settingsButton);
			
		
			
			JLabel cafenamelabe1 = new JLabel();
			cafenamelabe1.setBounds(500,170,600,50);
			cafenamelabe1.setText("Seating Arrangement");
			cafenamelabe1.setFont(new Font("Plain", Font.PLAIN, 21));
			add(cafenamelabe1);
			
			

			JPanel table1 = new JPanel();
			table1.setBackground(Color.white);
			table1.setBounds(200,300,200,50);
			table1.setLayout(null);
			table1.setSize(200,100);
			add(table1);
			table1.setVisible(true);

			JPanel table2 = new JPanel();
			table2.setBackground(Color.white);
			table2.setBounds(200,500,200,50);
			table2.setLayout(null);
			table2.setSize(200,100);
			add(table2);
			table2.setVisible(true);

			JPanel table3 = new JPanel();
			table3.setBackground(Color.white);
			table3.setBounds(800,300,200,50);
			table3.setLayout(null);
			table3.setSize(200,100);
			add(table3);
			table3.setVisible(true);

			JPanel table4 = new JPanel();
			table4.setBackground(Color.white);
			table4.setBounds(800,500,200,50);
			table4.setLayout(null);
			table4.setSize(200,100);
			add(table4);
			table4.setVisible(true);

			JLabel tablename1 = new JLabel();
			tablename1.setBackground(Color.black);
			tablename1.setBounds(70,25,100,45);
			tablename1.setText("Table 1");
			tablename1.setFont(new Font("Italic", Font.ITALIC, 18));
			table1.add(tablename1);

			JLabel tablename2 = new JLabel();
			tablename2.setBackground(Color.black);
			tablename2.setBounds(70,25,100,45);
			tablename2.setText("Table 2");
			tablename2.setFont(new Font("Italic", Font.ITALIC, 18));
			table2.add(tablename2);

			JLabel tablename3 = new JLabel();
			tablename3.setBackground(Color.black);
			tablename3.setBounds(70,25,100,45);
			tablename3.setText("Table 3");
			tablename3.setFont(new Font("Italic", Font.ITALIC, 18));
			table3.add(tablename3);

			JLabel tablename4 = new JLabel();
			tablename4.setBackground(Color.black);
			tablename4.setBounds(70,25,100,45);
			tablename4.setText("Table 4");
			tablename4.setFont(new Font("Italic", Font.ITALIC, 18));
			table4.add(tablename4);
			
			
			
			
			
		
			JTextField testField = new JTextField();
			testField.setBounds(80,160,1050,70);
			testField.setFont(new Font("Plain", Font.PLAIN, 21));
			testField.setEditable(false);
			add(testField);
			
			
			
			
			
			setVisible(true);
		}
		
		
		public void disposeThisFrame() {
			
			dispose();
			
		}
		
		private class ExitButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {
				JFrame frame = new JFrame();
				frame.setVisible(false);
				int a = JOptionPane.showConfirmDialog(frame,"Are you sure?");
				if(a == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
				else {
					frame.dispose();
				}
				
			}
				
		}
		private class SettingsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					SettingsFrame frame = new SettingsFrame();
				
				}
				
			}
		private class AccountButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					AccountFrame frame = new AccountFrame();
					
				}
				
			}
		private class ReservationsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();	
				Reservation frame = new Reservation();
								
			}
			
			
		}		
		private class MainMenuButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				MainMenuFrameOne frame = new MainMenuFrameOne();
				
								
			}
			
			
		}
		private class OffersButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();	
				OffersButtonFrame frame = new OffersButtonFrame();					
			}
				
		}
		private class menuButton1Handler implements ActionListener{
	
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				restaurantPanel3 frame = new restaurantPanel3();					
			}
		
		}
		private class menuButton2Handler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				Comments3 frame = new Comments3();					
			}
		
		}
		private class menuButton3Handler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				sitting3 frame = new sitting3();					
			}
		
		}
		private class menuButton4Handler implements ActionListener{
	
	@Override
	public void actionPerformed(ActionEvent e) {

		disposeThisFrame();	
		Events3 frame = new Events3();					
	}

}
		private class menuButton5Handler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				Contact3 frame = new Contact3();					
			}
		
		}


}	