import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Events1 extends JFrame{
		
		public Events1() {
			
			super("OccupancyNow");
			setSize(1215,810);
			setLayout(null);
			setBackground(Color.lightGray);
			setResizable(false);
			
			JPanel rightPanel = new JPanel();
			rightPanel.setBounds(1140,0,75,810);
			rightPanel.setBackground(Color.DARK_GRAY);
			add(rightPanel);
			
			JPanel leftPanel = new JPanel();
			leftPanel.setBounds(0,0,75,810);
			leftPanel.setBackground(Color.DARK_GRAY);
			add(leftPanel);
			
			JPanel bottomPanel = new JPanel();
			bottomPanel.setBounds(0,700,1215,1);
			bottomPanel.setBackground(Color.DARK_GRAY);
			add(bottomPanel);
			
			JPanel topPanel = new JPanel();
			topPanel.setBounds(0,80,1215,1);
			topPanel.setBackground(Color.DARK_GRAY);
			add(topPanel);
			
			JButton menuButton1 = new JButton("Menu");
			menuButton1.setBounds(120,80,170,60);
			menuButton1Handler handler11 = new menuButton1Handler();
			menuButton1.addActionListener(handler11);
			add(menuButton1);
			
			JButton menuButton2 = new JButton("Comments");
			menuButton2.setBounds(320,80,170,60);
			menuButton2Handler handler12 = new menuButton2Handler();
			menuButton2.addActionListener(handler12);
			add(menuButton2);
			
			JButton menuButton3 = new JButton("Seating");
			menuButton3.setBounds(520,80,170,60);
			menuButton3Handler handler13 = new menuButton3Handler();
			menuButton3.addActionListener(handler13);
			add(menuButton3);
			
			JButton menuButton4 = new JButton("Events");
			menuButton4.setBounds(720,80,170,60);
			menuButton4Handler handler14 = new menuButton4Handler();
			menuButton4.addActionListener(handler14);
			add(menuButton4);
			
			JButton menuButton5 = new JButton("Contact");
			menuButton5.setBounds(920,80,170,60);
			menuButton5Handler handler15 = new menuButton5Handler();
			menuButton5.addActionListener(handler15);
			add(menuButton5);
			
			JButton reservationsButton = new JButton("Reservations");
			reservationsButton.setBounds(130,710,170,60);
			ReservationsButtonHandler handler1 = new ReservationsButtonHandler();
			reservationsButton.addActionListener(handler1);
			add(reservationsButton);
			
			JButton mainMenuButton = new JButton("Main Menu");
			mainMenuButton.setBounds(520,710,170,60);
			MainMenuButtonHandler handler2 = new MainMenuButtonHandler();
			mainMenuButton.addActionListener(handler2);
			add(mainMenuButton);
			
			JButton offersButton = new JButton("Offers");
			offersButton.setBounds(915,710,170,60);	
			OffersButtonHandler handler3 = new OffersButtonHandler();
			offersButton.addActionListener(handler3);
			add(offersButton);
			
			JTextField searchBar = new JTextField();
			searchBar.setBounds(865,28,180,45);
			searchBar.setFont(new Font("Plain", Font.PLAIN, 18));
			add(searchBar);
			
			Image searchImg = new ImageIcon(this.getClass().getResource("search.png")).getImage();
			JButton searchButton = new JButton(new ImageIcon(searchImg));
			searchButton.setBounds(1050,30,50,40);
			searchButton.setContentAreaFilled(false);
			searchButton.setBorderPainted(false);
			add(searchButton);
			
			Image nameImg = new ImageIcon(this.getClass().getResource("OccupancyNow2.png")).getImage();
			JLabel nameLabel = new JLabel();
			nameLabel.setIcon(new ImageIcon(nameImg));
			nameLabel.setBounds(380,28,450,60);
			add(nameLabel);
			
			Image accountImg = new ImageIcon(this.getClass().getResource("account3.png")).getImage();
			JButton accountButton = new JButton();
			accountButton.setIcon(new ImageIcon(accountImg));
			accountButton.setBounds(170,25,50,50);
			accountButton.setContentAreaFilled(false);
			accountButton.setBorderPainted(false);
			AccountButtonHandler handler5 = new AccountButtonHandler();
			accountButton.addActionListener(handler5);
			add(accountButton);
			
			Image exitImg = new ImageIcon(this.getClass().getResource("exit.png")).getImage();
			JButton exitButton = new JButton();
			exitButton.setIcon(new ImageIcon(exitImg));
			exitButton.setBounds(100,25,50,50);
			exitButton.setContentAreaFilled(false);
			exitButton.setBorderPainted(false);
			ExitButtonHandler handler4 = new ExitButtonHandler();
			exitButton.addActionListener(handler4);
			add(exitButton);
			
			Image settingsImg = new ImageIcon(this.getClass().getResource("settings.png")).getImage();
			JButton settingsButton = new JButton();
			settingsButton.setIcon(new ImageIcon(settingsImg));
			settingsButton.setBounds(240,25,50,50);
			settingsButton.setContentAreaFilled(false);
			settingsButton.setBorderPainted(false);
			SettingsButtonHandler handler6 = new SettingsButtonHandler();
			settingsButton.addActionListener(handler6);
			add(settingsButton);
		
			
			
			JLabel eventnamelabe1 = new JLabel();
			eventnamelabe1.setBounds(535,170,200,50);
			eventnamelabe1.setText("Events");
			eventnamelabe1.setFont(new Font("Plain", Font.BOLD, 24));
			add(eventnamelabe1);
			
			JPanel testField = new JPanel();
			testField.setBounds(80,160,1050,70);
			testField.setBackground(Color.white);
			testField.setLayout(null);
			add(testField);
			
			
			JLabel events1 = new JLabel();
			events1.setBackground(Color.white);
			events1.setBounds(225,250,350,50);
			events1.setText("Canlı Müzik Gecesi");
			events1.setFont(new Font("Italic", Font.ITALIC, 18));
			add(events1);
			 
			
			JLabel eventsdate1 = new JLabel();
			eventsdate1.setBackground(Color.white);
			eventsdate1.setBounds(725,250,350,50);
			eventsdate1.setText("10.07.2023");
			eventsdate1.setFont(new Font("Italic", Font.ITALIC, 18));
			add(eventsdate1);
			
			
			JPanel testField1 = new JPanel();
			testField1.setBounds(80,240,1050,70);
			testField1.setBackground(Color.white);
			testField1.setLayout(null);
			add(testField1);
						
			
			JLabel events2 = new JLabel();
			events2.setBackground(Color.white);
			events2.setBounds(225,330,350,50);
			events2.setText("Pizza Festivali");
			events2.setFont(new Font("Italic", Font.ITALIC, 18));
			add(events2);
			 
			
			JLabel eventsdate2 = new JLabel();
			eventsdate2.setBackground(Color.white);
			eventsdate2.setBounds(725,330,350,50);
			eventsdate2.setText("22.08.2023");
			eventsdate2.setFont(new Font("Italic", Font.ITALIC, 18));
			add(eventsdate2);
			
			
			JPanel testField2 = new JPanel();
			testField2.setBounds(80,320,1050,70);
			testField2.setBackground(Color.white);
			testField2.setLayout(null);
			add(testField2);
						
			
			JLabel events3 = new JLabel();
			events3.setBackground(Color.white);
			events3.setBounds(225,410,350,50);
			events3.setText("Çocuklar İçin Pizza Atölyesi");
			events3.setFont(new Font("Italic", Font.ITALIC, 18));
			add(events3);
			 
			
			JLabel eventsdate3 = new JLabel();
			eventsdate3.setBackground(Color.white);
			eventsdate3.setBounds(725,410,350,50);
			eventsdate3.setText("05.09.2023");
			eventsdate3.setFont(new Font("Italic", Font.ITALIC, 18));
			add(eventsdate3);
			
			JPanel testField3 = new JPanel();
			testField3.setBounds(80,400,1050,70);
			testField3.setBackground(Color.white);
			testField3.setLayout(null);
			add(testField3);
			
			JLabel events4 = new JLabel();
			events4.setBackground(Color.white);
			events4.setBounds(225,490,350,50);
			events4.setText("Açılış Partisi ");
			events4.setFont(new Font("Italic", Font.ITALIC, 18));
			add(events4);

			JLabel eventsdate4 = new JLabel();
			eventsdate4.setBackground(Color.white);
			eventsdate4.setBounds(725,490,350,50);
			eventsdate4.setText("15.10.2023");
			eventsdate4.setFont(new Font("Italic", Font.ITALIC, 18));
			add(eventsdate4);

			JPanel testField4 = new JPanel();
			testField4.setBounds(80,480,1050,70);
			testField4.setBackground(Color.white);
			testField4.setLayout(null);
			add(testField4);


			JLabel events5 = new JLabel();
			events5.setBackground(Color.white);
			events5.setBounds(225,570,350,50);
			events5.setText("Lezzet Tadımı Etkinliği");
			events5.setFont(new Font("Italic", Font.ITALIC, 18));
			add(events5);

			JLabel eventsdate5 = new JLabel();
			eventsdate5.setBackground(Color.white);
			eventsdate5.setBounds(725,570,350,50);
			eventsdate5.setText("25.11.2023");
			eventsdate5.setFont(new Font("Italic", Font.ITALIC, 18));
			add(eventsdate5);

			JPanel testField5 = new JPanel();
			testField5.setBounds(80,560,1050,70);
			testField5.setBackground(Color.white);
			testField5.setLayout(null);
			add(testField5);

			
			setVisible(true);
		}
		
		public void disposeThisFrame() {
			
			dispose();
			
		}
		
		private class ExitButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {
				JFrame frame = new JFrame();
				frame.setVisible(false);
				int a = JOptionPane.showConfirmDialog(frame,"Are you sure?");
				if(a == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
				else {
					frame.dispose();
				}
				
			}
				
		}
		
		private class SettingsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					SettingsFrame frame = new SettingsFrame();
				
				}
				
			}
		
		private class AccountButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent event) {

					disposeThisFrame();
					AccountFrame frame = new AccountFrame();
					
				}
				
			}
				
		
		private class ReservationsButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();	
				Reservation frame = new Reservation();
								
			}
			
			
		}
		
		private class MainMenuButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				MainMenuFrameOne frame = new MainMenuFrameOne();
				
								
			}
			
			
		}
		
		private class OffersButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();	
				OffersButtonFrame frame = new OffersButtonFrame();					
			}
				
		}
		


		private class menuButton1Handler implements ActionListener{
	
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				restaurantPanel1 frame = new restaurantPanel1();					
			}
		
		}
		
		private class menuButton2Handler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				Comments1 frame = new Comments1();					
			}
		
		}
private class menuButton3Handler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				sitting1 frame = new sitting1();					
			}
		
		}
private class menuButton4Handler implements ActionListener{
	
	@Override
	public void actionPerformed(ActionEvent e) {

		disposeThisFrame();	
		Events1 frame = new Events1();					
	}

}
private class menuButton5Handler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				disposeThisFrame();	
				Contact1 frame = new Contact1();					
			}
		
		}


}