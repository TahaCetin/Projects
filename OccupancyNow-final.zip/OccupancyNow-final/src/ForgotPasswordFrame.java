import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ForgotPasswordFrame extends JFrame{
	
		public ForgotPasswordFrame() {
			
			super("OccupancyNow");
			setSize(1215,810);
			setLayout(null);
			setBackground(Color.lightGray);
			setResizable(false);
			
			JPanel rightPanel = new JPanel();
			rightPanel.setBounds(1140,0,75,810);
			rightPanel.setBackground(Color.DARK_GRAY);
			add(rightPanel);
			
			JPanel leftPanel = new JPanel();
			leftPanel.setBounds(0,0,75,810);
			leftPanel.setBackground(Color.DARK_GRAY);
			add(leftPanel);
			
			JLabel topLabel = new JLabel("Change Your Password");
			topLabel.setBounds(440,40,500,120);
			topLabel.setFont(new Font("Roman", Font.ITALIC ,30));
			topLabel.setForeground(Color.gray);
			add(topLabel);
			
			JLabel usernameLabel = new JLabel();
			usernameLabel.setBounds(355,175,140,60);
			usernameLabel.setText("Username:");
			usernameLabel.setFont(new Font("Plain", Font.PLAIN, 21));
			add(usernameLabel);
			
			JTextField usernameField = new JTextField();
			usernameField.setBounds(500,185,300,60);
			usernameField.setFont(new Font("Plain", Font.PLAIN, 21));
			add(usernameField);
			
			Image okImg = new ImageIcon(this.getClass().getResource("ok.png")).getImage();
			
			JButton button1 = new JButton();
			button1.setIcon(new ImageIcon(okImg));
			button1.setBounds(805,185,60,60);
			button1.setContentAreaFilled(false);
	        button1.setBorderPainted(false);
			add(button1);

			JLabel verifyCodeLabel = new JLabel();
			verifyCodeLabel.setBounds(342,270,180,60);
			verifyCodeLabel.setText("Verify Code:");
			verifyCodeLabel.setFont(new Font("Plain", Font.PLAIN, 21));
			add(verifyCodeLabel);
			
			JTextField verifyCodeField = new JTextField();
			verifyCodeField.setBounds(500,275,300,60);
			verifyCodeField.setFont(new Font("Plain", Font.PLAIN, 21));
			add(verifyCodeField);
			
			JButton button2 = new JButton();
			button2.setIcon(new ImageIcon(okImg));
			button2.setBounds(805,275,60,60);
			button2.setContentAreaFilled(false);
	        button2.setBorderPainted(false);
			add(button2);

			JLabel passwordLabel = new JLabel();
			passwordLabel.setBounds(365,360,160,60);
			passwordLabel.setText("Password:");
			passwordLabel.setFont(new Font("Plain", Font.PLAIN, 21));
			add(passwordLabel);
			
			JPasswordField passwordField = new JPasswordField();
			passwordField.setBounds(500,365,300,60);
			passwordField.setFont(new Font("Plain", Font.PLAIN, 21));
			add(passwordField);
						
			JButton button3 = new JButton();
			button3.setIcon(new ImageIcon(okImg));
			button3.setBounds(805,365,60,60);
			button3.setContentAreaFilled(false);
	        button3.setBorderPainted(false);
			add(button3);
			
			JLabel repeatPasswordLabel = new JLabel();
			repeatPasswordLabel.setBounds(297,450,200,60);
			repeatPasswordLabel.setText("Password(again):");
			repeatPasswordLabel.setFont(new Font("Plain", Font.PLAIN, 21));
			add(repeatPasswordLabel);
			
			JPasswordField repeatPasswordField = new JPasswordField();
			repeatPasswordField.setBounds(500,450,300,60);
			repeatPasswordField.setFont(new Font("Plain", Font.PLAIN, 21));
			add(repeatPasswordField);
						
			JButton button4 = new JButton();
			button4.setIcon(new ImageIcon(okImg));
			button4.setBounds(805,450,60,60);
			button4.setContentAreaFilled(false);
	        button4.setBorderPainted(false);
			add(button4);

			
			JButton changeButton = new JButton("Done!");
			changeButton.setBounds(700,560,100,55);
			ChangeButtonHandler handler1 = new ChangeButtonHandler();
			changeButton.addActionListener(handler1);
			add(changeButton);
			
			JButton returnButton = new JButton("Return");
			returnButton.setBounds(500,560,90,55);
			ReturnButtonHandler handler2 = new ReturnButtonHandler();
			returnButton.addActionListener(handler2);
			add(returnButton);
			
			
			setVisible(true);
			
		}
		
		public void disposeThisFrame() {
			
			dispose();
			
		}
		
		private class ChangeButtonHandler implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				
				JFrame f=new JFrame(); 
				JOptionPane.showMessageDialog(f,"Your password is changed successfully.","Response",JOptionPane.INFORMATION_MESSAGE);  

				
								
			}

		}
		
		private class ReturnButtonHandler implements ActionListener{
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				disposeThisFrame();
				LoginFrame frame = new LoginFrame();
				
								
			}
	
		}

}
