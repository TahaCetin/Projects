import java.util.*;
import javax.swing.*;
import java.awt.*;


public class ProjectMain {

	public static void main(String[] args) {
		
		LoginFrame frame = new LoginFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

}	
